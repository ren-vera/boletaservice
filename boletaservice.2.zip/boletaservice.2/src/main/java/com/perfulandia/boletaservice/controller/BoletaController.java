package com.perfulandia.boletaservice.controller;

import com.perfulandia.boletaservice.model.Boleta;
import com.perfulandia.boletaservice.service.BoletaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/boletas")
@CrossOrigin(origins = "*")
public class BoletaController {
    @Autowired
    private BoletaService boletaService;


    @PostMapping
    public ResponseEntity<?> crearBoleta(@RequestBody Boleta boleta) {
        try {
            Boleta nuevaBoleta = boletaService.crearBoleta(boleta);
            return ResponseEntity.ok(nuevaBoleta);
        } catch (RuntimeException e) {
// Si ocurre una excepción (por ejemplo, usuario no válido), devolvemos un error 400 Bad Request
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/usuario/{idUsuario}")
    public ResponseEntity<List<Boleta>> obtenerBoletasPorUsuario(@PathVariable Long idUsuario) {
        List<Boleta> boletas = boletaService.obtenerBoletasPorUsuario(idUsuario);
        return ResponseEntity.ok(boletas);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Boleta> obtenerBoletaPorId(@PathVariable Long id) {
        return boletaService.obtenerBoletaPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    public ResponseEntity<List<Boleta>> obtenerTodasLasBoletas() {
        return ResponseEntity.ok(boletaService.obtenerTodas());
    }

}