package com.perfulandia.boletaservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoletaserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoletaserviceApplication.class, args);
	}

}
