package com.perfulandia.boletaservice.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@Getter
@Entity
public class Boleta {
    // Getters y Setters
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Setter
    private Long idUsuario;
    @Setter
    private Date fechaEmision;
    @Setter
    private Double totalNeto;
    @Setter
    private Double iva;
    @Setter
    private Double totalFinal;

    @Setter
    @OneToMany(mappedBy = "boleta", cascade = CascadeType.ALL)
    private List<DetalleBoleta> detalles;

}

