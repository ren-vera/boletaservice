package com.perfulandia.boletaservice.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Entity
public class DetalleBoleta {
    // Getters y setters
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombreProducto;
    @Setter
    private Integer cantidad;
    @Setter
    private Double precioUnitario;

    @Setter
    @ManyToOne
    @JoinColumn(name = "boleta_id")
    private Boleta boleta;

}
